/*
Omer shay
322480807
*/
#pragma once
#include "Appartment.h"
using namespace std;

class Apartment;
class Building 
{
protected:
	string Building_Adress;
	int FloorAmount;
	Appartment** AppPtr;

public:
	string GetAdress();
	int GetFloorAmount();
	Appartment* getApartment(int app_id);
	Building();
	Building(string Building_Adress, int FloorAmount, Appartment** AppPtr);
	Building(const Building& copy); //copy Ctor 
	virtual ~Building(); //Dtor
	virtual void print();
	 


};

