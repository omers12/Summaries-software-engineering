#pragma once
#include <iostream>
#include <string>
#include <iomanip> 
#include<typeinfo>// RTTI


class Appartment
{
protected:
	int AppartmentID;
	int floor;
	int Area;
	bool IS_sale;

public:
	Appartment();
	Appartment(const Appartment& copyAppartment);//copy Ctor
	Appartment(int AppartmentID, int floor, int Area, bool IS_sale); //manual Ctor
	virtual ~Appartment(); //Dtor
	virtual int Appartmment_Price(); //return the price of the appartment
	virtual void print() ; //print the details of the appartment
	int getAppartmentSize();
	int getid();
	virtual void setApp();
	virtual bool getsoldornot();
	void bought();
	//Appartment& operator = (Appartment* App);
};



