#pragma once
#include "Appartment.h"
class Penthouse :public Appartment
{
protected:
	int Balcony_Pent_Size;
public:
	Penthouse();// def Ctor 
	Penthouse(int AppartmentID, int floor, int Area, bool IS_sale,int Balcony_Pent_Size); //Manual Ctor
	Penthouse(const Penthouse& copy); //Copy ctor
	~Penthouse();//Dtor
	void print();
	void setApp();
	int Appartmment_Price();
};

