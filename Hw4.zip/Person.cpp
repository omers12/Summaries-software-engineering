#include "Person.h"

Person::Person():firstName("UnKnown"), lastName("UnKnown"){}


Person:: Person(string first, string last) {
	this->firstName = first;
	this->lastName = last;
}

void Person::print()const {
	cout << "First Name: " << firstName << endl;
	cout << "Last Name: " << lastName << endl;
}
void Person::setPerson()
{
	cout << "Please enter your first name:"<<endl;
	cin >> firstName;
	cout << "Please enter your last name:" << endl;
	cin >> lastName;
}

string Person::getfirstname()
{
	return this->firstName;
}

string Person::getlastname()
{
	return this->lastName;
}





Person::Person(const Person& obj) {
	this->firstName = obj.firstName;
	this->lastName = obj.lastName;
}
Person::~Person(){}


