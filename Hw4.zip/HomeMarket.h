/*
Omer shay
322480807
*/
#pragma once
#include "Appartment.h"
#include "Building.h"
#include "Customer.h"
#include "Garden.h"
#include "HomeMarket.h"
#include "Penthouse.h"
#include "SalesMan.h"
#include"StandardAppartment.h"

#include <stdio.h>
class HomeMarket
{
protected:
	Person** PersonArray;
	Appartment** AppartemntArray;
	Project** ProjectArray;
	int NumOfPerson;
	int NumOfAppartment;
	int NumOfProject;

public:
	HomeMarket();
	~HomeMarket();
	bool isBoughtStandart(Customer* c);
	void Menu();
	bool Add_building();
	void Print_details();
	bool AddProject();
	Project** getProjectArray();
	void Add_SalesMan();
	void Add_Customer();
	void Print_Apartment_by_Number();
	void Print_details_with_balcony();
	void Print_salesman_Salary();
	void Print_best_Apartments_details();
	void Print_price_Penthouse();
	void sale_Apartment();
	void Print_lowest_Arnona();
};

