/*
Omer shay
322480807
*/
#include "Project.h"
#include "Building.h"
#include <string.h>
#include "Garden.h"
#include "Standard_Appartment.h"
#include "Penthouse.h"

Project::Project() :ProjectName("Unknown"), BuildingsAmount(0), BuildingArray(nullptr) {}

Project::~Project() {
	if (BuildingArray != NULL) {
		for (int i = 0; i < BuildingsAmount; i++)
			delete BuildingArray[i];
		delete [] BuildingArray;
	}
}
Project::Project(string ProjectName, int BuildingsAmount, Building** BuildingArray) {
	this->ProjectName = ProjectName;
	this->BuildingsAmount = BuildingsAmount;
	this->BuildingArray = new Building * [BuildingsAmount];
	for (int i = 0; i < BuildingsAmount; i++)
		this->BuildingArray[i] = BuildingArray[i];
}


Project& Project::operator+=(Building* newBuilding) {
	Building** temp;
	temp = new Building * [++BuildingsAmount]; //increase the array in 1 
	for (int i = 0; i < BuildingsAmount-1; i++)
		temp[i] = BuildingArray[i];
	temp[BuildingsAmount - 1] = newBuilding;
	delete [] BuildingArray;
	BuildingArray = temp;
	return *this;
}

//void Project::addBuilding(Building* BuildingPtr) {
//	*this += BuildingPtr; //call += operator
//}

int Project::printNumBuilding(string Building_Adress) {
	for (int i = 0; i < BuildingsAmount; i++)
		if (BuildingArray[i]->GetAdress().compare(Building_Adress)) {
			if (BuildingArray[i]->GetFloorAmount() >= 2)
				return BuildingArray[i]->GetFloorAmount() * 2 - 2;
			else
				return BuildingArray[i]->GetFloorAmount();
		}
		else
			return -1;

}

string Project::getprojectName() {
	return ProjectName;
}

int Project::getBuildsAmount()
{
	return BuildingsAmount;
}

Building** Project::getbuildingArray()
{
	return BuildingArray;
}

void Project::setProject()
{
	int BuildingsAmount ;
	cout << "Please enter the project's name:";
	cin >> ProjectName;

	cout << "Please enter the project's buildings amount:";
	cin >> BuildingsAmount;

	Building* temp;
	for (int i = 0; i < BuildingsAmount; i++)
	{
		temp = new Building();

		//put all info of buldings in temp array and than add building 
		string building_Adress;
		int buildlevels;
		int whichApartment = 0;
		Appartment** AppartemntArray;

		cout << "enter building Adress to add your building to :" << endl;
		cin >> building_Adress;
		cout << "Enter Building levels to add to your Building: " << endl;
		cin >> buildlevels;
		int AppAmount = 0;
		if (buildlevels <= 1) {
			AppAmount = buildlevels;
			AppartemntArray = new Appartment * [AppAmount];
		}


		else {
			AppAmount = 2 * buildlevels - 2;
			AppartemntArray = new Appartment * [AppAmount];
		}



		//Garden , PentHouse , Standard 
		int Gamount1 = 0, Pamount2 = 0, Samount3 = 0; //
		for (int i = 0; i < AppAmount; i++)
		{
			cout << "Which kind of Apartment you want to add your building: " << endl;
			cout << "For GardenApartment Press 1, for PenthouseApartment Press 2, for StandardApartment Press 3" << endl;
			cin >> whichApartment;
			if (whichApartment == 1)
			{
				Gamount1++;

			}
			else if (whichApartment == 2)
			{
				Pamount2++;
			}
			else if (whichApartment == 3)
			{
				Samount3++;
			}
			else {
				cout << "Error!. Wrong Choice, Please Start again" << endl;
				break;
			}
		}

		for (int i = 0; i < Gamount1; i++) {
			AppartemntArray[i] = new Garden();
			cout << "Enter data for garden #" << i + 1;
			AppartemntArray[i]->setApp();
		}
		for (int i = Gamount1; i < Pamount2; i++) {
			AppartemntArray[i] = new Penthouse();
			cout << "Enter data for PentHouse #" << i + 1 - Gamount1;
			AppartemntArray[i]->setApp();
		}
		for (int i = Pamount2; i < Samount3; i++) {
			AppartemntArray[i] = new Standard_Appartment();
			cout << "Enter data for Standard #" << i + 1 - Pamount2;
			AppartemntArray[i]->setApp();
		}
		
		Building* building = new Building(building_Adress, buildlevels, AppartemntArray);
		*this += building;
	}

}

void Project::setName(string name)
{
	this->ProjectName = name;
}
