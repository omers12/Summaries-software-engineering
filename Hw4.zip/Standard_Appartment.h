#pragma once
#include "Appartment.h"

class Standard_Appartment :public Appartment 
{
protected:

	int balconyNumber; //balkony number 
	int* Balconysize; //array of balkony sizes

public:
	Standard_Appartment(); //default Ctor
	Standard_Appartment(int AppartmentID, int floor, int Area, bool IS_sale, int balconyNumber, int* Balconysize);
	Standard_Appartment(const Standard_Appartment& copy);//Copy Ctor
	~Standard_Appartment(); //Dtor
	int Appartmment_Price();// method that return the price of the appartment
	void print(); //print function 
	int TwoBalconys();
	void setApp();
	bool getbalconyamount();
	
};

