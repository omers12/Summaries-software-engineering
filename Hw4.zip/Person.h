/*
Omer shay
322480807
*/
#pragma once
#include <iostream>
#include<typeinfo>// RTTI
#include <string>
using namespace std;

class Person
{
private:
	string firstName;
	string lastName;

public:
	Person(); //defualt Ctor
	Person(string first, string last); //Manual Ctor
	Person(const Person& obj); //copy Ctor
	~Person(); //Dtor
	virtual void print()const; //function that print the details of person 
	void setPerson();
	string getfirstname();
	string getlastname();

};

