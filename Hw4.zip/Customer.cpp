/*
Omer shay
322480807
*/
#pragma once
#include "Customer.h"
#include "Person.h"
#include "Project.h"
#include "Appartment.h"

int Customer::CustomerID = 0;
Customer::Customer():Num_Of_Appartments(0), budget(0), appartmentArr(NULL),dates(NULL),Person(){}

Customer::Customer(int Num_Of_Appartments, int budget, Appartment** appartmentArr, Date** dates){
	 
	this->Num_Of_Appartments = Num_Of_Appartments;
	this->budget = budget;
	for (int i = 0; i < Num_Of_Appartments; i++) {
		this->appartmentArr[i] = appartmentArr[i];
	}
	for (int i = 0; i < Num_Of_Appartments; i++) {
		this->dates[i] = dates[i];
	}
	
	
}
Customer::Customer(const Customer& copy) {
	this->Num_Of_Appartments = copy.Num_Of_Appartments;
	this->budget = copy.budget;
	for (int i = 0; i < Num_Of_Appartments; i++) {
		this->appartmentArr[i] = copy.appartmentArr[i];
	}
	for (int i = 0; i < Num_Of_Appartments; i++) {
		this->dates[i] = copy.dates[i];
	}
}

Customer::~Customer() {
	if (appartmentArr != NULL) {
		for (int i = 0; i < Num_Of_Appartments; i++)
			delete appartmentArr[i];
	}
	delete appartmentArr;

	if (dates != NULL)
		for (int i = 0; i < Num_Of_Appartments; i++)
			delete dates[i];
	delete dates;

}
int Customer::getNumOfApps() {
	return Num_Of_Appartments;
}

int Customer::getdate(int numApt)const {
	return dates[numApt]->GetMonth();
}

Appartment** Customer::getApps()const{
	return appartmentArr;
}



void Customer::print()const { //print method for all client info.
	cout << "---------------------------------------------------" << endl;

	Person::print();
	cout << "the budget is: " << budget << endl;
	cout << "the number of apartments: " << Num_Of_Appartments << endl;
	cout << "client ID: " << CustomerID << endl;
	cout << "Apartments info: " << endl;
	for (int i = 0; i < Num_Of_Appartments; i++)
	{

		Garden* pG = dynamic_cast<Garden*>(appartmentArr[i]);
		if (pG) {
			pG->print();
		}
		Penthouse* pH = dynamic_cast<Penthouse*>(appartmentArr[i]);
		if (pH) {
			pH->print();
		}
		Standard_Appartment* pW2 = dynamic_cast<Standard_Appartment*>(appartmentArr[i]);
		if (pW2) {
			pW2->print();
		}
		cout << "Apartment number: " << i + 1 << " been sold in date: ";
		dates[i]->PrintDate();
		cout << endl;
	}
	cout << "---------------------------------------------------" << endl;

}

void Customer::setCustomer()
{
	Person::setPerson(); //get first and last name
	cout << "enter your budget" << endl;

	cin >> budget;
}

int Customer::getCT_Id()
{
	return CustomerID;
}

int Customer::getBudget()
{
	return budget;
}

void Customer::Buy(Appartment* apartment, Date* date)
{
	if (this->budget >= apartment->Appartmment_Price()) {
		apartment->bought();
		this->budget -= apartment->Appartmment_Price();
		Appartment** tempa = new Appartment * [this->Num_Of_Appartments];
		Date** tempd = new Date * [this->Num_Of_Appartments];
		for (int i = 0; i < this->Num_Of_Appartments; i++) {
			tempa[i] = this->appartmentArr[i];
			tempd[i] = this->dates[i];
		}
		if (this->appartmentArr)
			delete this->appartmentArr;
		if (this->dates)
			delete this->dates;
		this->Num_Of_Appartments++;
		this->appartmentArr = new Appartment * [this->Num_Of_Appartments];
		this->dates = new Date * [this->Num_Of_Appartments];
		for (int i = 0; i < this->Num_Of_Appartments - 1; i++) {
			this->appartmentArr[i] = tempa[i];
			this->dates[i] = tempd[i];
		}
		delete tempa;
		delete tempd;
		this->appartmentArr[this->Num_Of_Appartments - 1] = apartment;
		this->dates[this->Num_Of_Appartments - 1] = date;
	}

}


int* Customer::Calculate_Arnona() {
	int* propertyTaxArray;//to store each tax for each apartment client have.
	propertyTaxArray = new int[Num_Of_Appartments]; //allocating new memory to put taxs.
	int typeOfApartment = 0, TwoBalconys = 0, SizeOfApartment = 0;
	for (int i = 0; i < Num_Of_Appartments; i++) //loop that check each apartment which kind of apartment its to calculate the final tax.
	{
		SizeOfApartment = appartmentArr[i]->getAppartmentSize();
		Garden* pW = dynamic_cast<Garden*>(appartmentArr[i]);
		if (pW) {
			typeOfApartment = 2;
		}
		Penthouse* pW1 = dynamic_cast<Penthouse*>(appartmentArr[i]);
		if (pW1) {
			typeOfApartment = 1;
		}
		Standard_Appartment* pW2 = dynamic_cast<Standard_Appartment*>(appartmentArr[i]);
		if (pW2) {
			typeOfApartment = 0;
		}
		Standard_Appartment* pW3 = dynamic_cast<Standard_Appartment*>(appartmentArr[i]);
		if (pW3) {

			if (pW3->TwoBalconys()) {
				TwoBalconys = 1;
			}
		}
		else
		{
			TwoBalconys = 0;
		}
		propertyTaxArray[i] = typeOfApartment * 120 + TwoBalconys * 300 + SizeOfApartment * 25;

	}

	if (Num_Of_Appartments == 0)
	{
		return NULL;
	}


	return propertyTaxArray;
}



