#pragma once
using namespace std;

class Date {
	int day, month, year;
public:
	Date();
	Date(int day, int month, int year);
	void SetDay(int day);
	void SetMonth(int month);
	void SetYear(int year);
	int GetDay();
	int GetMonth();
	int GetYear();
	void PrintDate();
	void PrintMonthName();
	int MonthDaysNum();
	bool Meuberet();
	void NextDayDate();
};