#include "StandardAppartment.h"


StandardAppartment::StandardAppartment(int AppartmentID, int floor, int squre, bool IS_sale, int balkonyNumber,int* Size){
	super()
}