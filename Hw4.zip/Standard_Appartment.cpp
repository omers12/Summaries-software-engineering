#pragma once
#include "Appartment.h"
#include "Standard_Appartment.h"
#include <iostream>
#include<typeinfo>// RTTI
#include <string>
using namespace std;
Standard_Appartment::Standard_Appartment():Appartment(), balconyNumber(0), Balconysize(nullptr){}

Standard_Appartment::Standard_Appartment(int AppartmentID, int floor, int Area, bool IS_sale, int balconyNumber, int* Balconysize) : Appartment(AppartmentID, floor, Area, IS_sale) {
	this->balconyNumber = balconyNumber;
	this->Balconysize = new int[balconyNumber];
	for (int i = 0; i < balconyNumber; i++)
		this->Balconysize[i] = Balconysize[i];
}
//Copy Ctor 
Standard_Appartment::Standard_Appartment(const Standard_Appartment& copy): Appartment(copy) {
	this->balconyNumber = balconyNumber;
	this->Balconysize = new int[balconyNumber];
	for (int i = 0; i < balconyNumber; i++)
		this->Balconysize[i] = copy.Balconysize[i];
}
//Dtor 
Standard_Appartment::~Standard_Appartment() {
	if(Balconysize!=nullptr)
	delete[] this->Balconysize;
}

int Standard_Appartment::Appartmment_Price() {
	return 300000 + balconyNumber * 12000 + this->floor * 300 + this->Area * 500;
}

void Standard_Appartment::print(){
	Appartment::print(); //call the print function of Appartement class
	//the Adds:
	cout << "Balcony Amount: " << this->balconyNumber << "\nBalcony Sizes: " << endl;
	for (int i = 0; i < this->balconyNumber; i++) {
		cout << "Balcony #" << i + 1 << ": " << this->Balconysize[i] << endl;
	}
}


int Standard_Appartment::TwoBalconys() {
	if (balconyNumber >= 0 && balconyNumber<=2)
		return 1;
}

void Standard_Appartment::setApp()
{
	Appartment::setApp();
	cout << "Please enter how many balconeis amount:";
	cin >> balconyNumber;

	Balconysize = new int[balconyNumber];
	for (int i = 0; i < balconyNumber; i++)
	{
		cout << "Please enter the #" << i + 1 << " balcony size:";
		cin >> Balconysize[i];
	}
}

bool Standard_Appartment::getbalconyamount()
{
	if (balconyNumber == 2)
		return true;
	else
		return false;
}


