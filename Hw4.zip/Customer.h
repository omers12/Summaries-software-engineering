#pragma once
#include "Person.h"
#include "Customer.h"
#include "Project.h"
#include "Appartment.h"
#include "Date.h"
#include "Garden.h"
#include "Penthouse.h"
class Appartment;
class Date;


class Customer :public Person
{
protected:
	static int CustomerID;
	int budget; //budget of customer
	Appartment** appartmentArr; // dynamic array of pointers to appartments
	Date** dates; //array of boughts dates
	int Num_Of_Appartments;

public:
	Customer(); //Default Ctor
	~Customer(); //Dtor
	Customer( int Num_Of_Appartments, int budget, Appartment** appartmentArr, Date** dates); // manual Ctor
	Customer(const Customer& copy); //Copy Ctor 
	int* Calculate_Arnona(); //calculate the sum to pay , if the customer doesnt buy a house return -1
	int getNumOfApps();
	int getdate(int numApt)const;
	Appartment** getApps()const; // dynamic array of pointers to appartments
	virtual void print()const;
	void setCustomer();
	int getCT_Id();
	int getBudget();
	void Buy(Appartment*, Date*);



};

