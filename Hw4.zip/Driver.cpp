/*
Omer shay 
322480807
*/
#pragma once 
#include "Customer.h"
#include "HomeMarket.h"
#include "SalesMan.h"
#include"Project.h"
#include "Standard_Appartment.h"
#include <string.h>
#include <iostream>


int main() {
	/*Project* p = new Project;
	Customer** c = new Customer*;

	SalesMan s("first", "last", p, 1, c);
	int sizes[] = { 10 };
	Standard_Appartment ss(1, 2, 3, false, 4, sizes);
	Garden g(4, 1, 60, false, 10, true);
	g.print();
	Appartment* arr[] = { &ss,&g };
	Building b("TEST", 2, arr);
	b.print();
	*/
	/**HomeMarket HM;
	HM.Menu();*/

	/*HomeMarket* hm = new HomeMarket();
	hm->AddProject();
	hm->Add_building();
	hm->Print_Apartment_by_Number();*/
	return 0;
}