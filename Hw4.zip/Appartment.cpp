#include "Appartment.h"
#include <iostream>
#include<typeinfo>// RTTI
using namespace std;


Appartment::Appartment(): AppartmentID(0), floor(0), Area(0), IS_sale(false){}

//copy CTor
Appartment::Appartment(const Appartment& copyAppartment) {
	this->AppartmentID = copyAppartment.AppartmentID;
	this->floor = copyAppartment.floor;
	this->Area = copyAppartment.Area;
	this->IS_sale = copyAppartment.IS_sale;
}
//Manual Ctor
Appartment::Appartment(int AppartmentID, int floor, int Area, bool IS_sale) {
	this->AppartmentID = AppartmentID;
	this->floor = floor;
	this->Area = Area;
	this->IS_sale = IS_sale;
}
//Dtor
Appartment::~Appartment() {}

int Appartment::Appartmment_Price()
{
	return 0;
}


void Appartment::print() 
{
	cout << "apartment Number: " << AppartmentID << endl;
	cout << "apartment Level: " << floor << endl;
	cout << "apartment Size: " << Area << endl;
	if (IS_sale == true)
	{
		cout << "The Apartment has been Sold" << endl;
	}
	else
	{
		cout << "The Apartment has not Sold yet" << endl;
	}
}



int Appartment::getAppartmentSize() {
	return Area;
}


int Appartment::getid() {
	return AppartmentID;
}

void Appartment::setApp()
{
	cout << "Please enter app id:";
	cin >> AppartmentID;

	cout << "Please enter floor number:";
	cin >> floor;

	cout << "Please enter app area:";
	cin >> Area;

	cout << "Please enter if the app has been sold:";
	cin >> IS_sale;
}

bool Appartment::getsoldornot()
{
	return IS_sale;
}

void Appartment::bought()
{
	this->IS_sale = true;
}

//Appartment& Appartment::operator=(Appartment* App)
//{
//	Appartment** temp;
//	temp= new Appartment*[++App]
//}
