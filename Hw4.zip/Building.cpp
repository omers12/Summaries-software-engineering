#include "Building.h"


Building::Building():Building_Adress("UnKnown"), FloorAmount(0), AppPtr(nullptr) {}

Building::Building(string Building_Adress, int FloorAmount, Appartment** AppPtr)
{
	this->Building_Adress = Building_Adress;
	this->FloorAmount = FloorAmount;
	if (FloorAmount ==1) {
		this->AppPtr = new Appartment * [1];
		this->AppPtr[0] = AppPtr[0];
	}
	else {
		this->AppPtr = new Appartment * [FloorAmount * 2 - 2];
		for (int i = 0; i < FloorAmount * 2 - 2; i++) {
			this->AppPtr[i] = AppPtr[i];
		}
	}
}

Building::Building(const Building& copy)
{
	Building(copy.Building_Adress, copy.FloorAmount, copy.AppPtr);
}

Building::~Building()
{
	if (FloorAmount == 1) {
		delete[] AppPtr[0];
	}
	else 
		for (int i = 0; i < FloorAmount * 2 - 2; i++)
		{
			delete[] this->AppPtr[i];
		}
	delete AppPtr;
}

void Building::print() {
	if (FloorAmount == 1) {
		this->AppPtr[0]->print();
	}
	for (int i = 0; i < FloorAmount * 2 - 2; i++) {
		this->AppPtr[i]->print();
	}
}

string Building::GetAdress() {
	return Building_Adress;
}

int Building::GetFloorAmount() {
	return FloorAmount;
}

Appartment* Building::getApartment(int app_id)
{
	return AppPtr[app_id];
}

