#pragma once
#include <stdbool.h>
#include "HomeMarket.h"
#include "Date.h"



HomeMarket::HomeMarket() :NumOfAppartment(4), NumOfProject(1) {
	AppartemntArray = new Appartment * [NumOfAppartment];
	AppartemntArray[0] = new Garden();
	AppartemntArray[1] = new Standard_Appartment();
	AppartemntArray[2] = new Standard_Appartment();
	AppartemntArray[3] = new Penthouse();


	Building** buildings = new Building * [1];
	buildings[0] = new Building("", 3, AppartemntArray);

	ProjectArray = new Project * [NumOfProject];
	ProjectArray[0] = new Project("Omer", 1, buildings);

	PersonArray = new Person * [1];
	PersonArray[0] = new Customer();
}

HomeMarket::~HomeMarket() {
	// Person Dtor 
	if (PersonArray != NULL) {
		for (int i = 0; i < NumOfPerson; i++)
			delete PersonArray[i];
		delete[]PersonArray;
	}

	//Apartment Dtor 
	if (AppartemntArray != NULL) {
		for (int i = 0; i < NumOfAppartment; i++)
			delete AppartemntArray[i];
		delete[] AppartemntArray;
	}

	//
	if (ProjectArray != NULL) {
		for (int i = 0; i < NumOfProject; i++)
			delete ProjectArray[i];
		delete[]ProjectArray;
	}
}

void HomeMarket::Menu()
{
	int choice;
	bool flag = false;

	do {
		cout << "----------------------  MENU ----------------------" << endl
			<< "1 . Print details of Customers who purchased standard apartments" << endl
			<< "2 . Add Building" << endl
			<< "3 . Add Project" << endl
			<< "4 . Add SalesMan" << endl
			<< "5 . Add Customer" << endl
			<< "6 . Print Apartment by Apartment's number & Building adress" << endl
			<< "7 . Print details of Apartment with 2 balcony that doesnt sold yet" << endl
			<< "8 . Print salesman's Salary" << endl
			<< "9 . Print Apartments details of the Apartments which id best for Customer " << endl
			<< "10. Print The price of Penthouse in current Projects" << endl
			<< "11. sale Apartment  "
			<< "12. Print the detils of the Customers with the smallest Arnona"
			<< "13 . Exit"
			<< "---------------------------------------------------" << endl << endl;
		cout << "Your choice : ";
		cin >> choice;
		switch (choice)
		{
		case 1:
			Print_details();
			break;

		case 2:
			Add_building();
			break;

		case 3:
			AddProject();
			break;
		case 4:
			Add_SalesMan();
			break;
		case 5:
			Add_Customer();
			break;
		case 6:
			Print_Apartment_by_Number();
			break;
		case 7:
			Print_details_with_balcony();
			break;
		case 8:
			Print_salesman_Salary();
			break;
		case 9:
			Print_best_Apartments_details();
			break;
		case 10:
			Print_price_Penthouse();
			break;
		case 11:
			sale_Apartment();
			break;
		case 12:
			Print_lowest_Arnona();
			break;
		case 13:
			cout << "Have a good day!" << endl;
			flag = true;
			break;

		default:
			cout << "Incorrect choice!" << endl;
			break;
		}
	} while (flag == true);
}


void HomeMarket::Print_details() {
	bool isStandart = false;
	for (int i = 0; i < NumOfPerson; i++) //loop that run over the Customers and print the details of which purchased standard Apartment
	{
		Customer* c = dynamic_cast<Customer*>(PersonArray[i]);
		if (c && isBoughtStandart(c)) {
			PersonArray[i]->print(); ////////////////????????????
			isStandart = true;
		}
	}
	if (!isStandart)
		cout << "Sorry There is no Standart Apartment" << endl;
	exit(1); //////////////////??????????????????????//////////////////////////////
}

bool HomeMarket::isBoughtStandart(Customer* c) {
	for (int i = 0; i < c->getNumOfApps(); i++) //getNumApps i need to write 
		if (dynamic_cast<Standard_Appartment*>(c->getApps()[i]))
			return true;
	return false;
}



// Case 2 
bool HomeMarket::Add_building() {
	Appartment** Apparr;
	string projectname;
	cout << "Enter Project name to add your building to: " << endl;
	cin >> projectname;

	int count = 0;
	int projindex = 0;

	for (int i = 0; i < NumOfProject; i++)
		if (ProjectArray[i]->getprojectName() == projectname) {
			count++; //use like a flag to show that the project exsist
			projindex = i;
		}
	if (count == 0) {
		cout << "Sorry.The Project doesnt Exsist!" << endl;
		return false;
	}


	//put all info of buldings in temp array and than add building 
	string building_Adress;
	int buildlevels;
	int whichApartment = 0;


	cout << "enter building Adress to add your building to :" << endl;
	cin >> building_Adress;
	cout << "Enter Building levels to add to your Building: " << endl;
	cin >> buildlevels;
	int AppAmount = 0;
	if (buildlevels <= 2) {
		AppAmount = buildlevels;
		Apparr = new Appartment * [AppAmount];
	}


	else {
		AppAmount = 2 * buildlevels - 2;
		Apparr = new Appartment * [AppAmount];
	}



	//Garden , PentHouse , Standard 
	int Gamount1 = 0, Pamount2 = 0, Samount3 = 0; //
	for (int i = 0; i < AppAmount; i++)
	{
		cout << "Which kind of Apartment you want to add your building: " << endl;
		cout << "For GardenApartment Press 1, for PenthouseApartment Press 2, for StandardApartment Press 3" << endl;
		cin >> whichApartment;
		if (whichApartment == 1)
		{
			Gamount1++;

		}
		else if (whichApartment == 2)
		{
			Pamount2++;
		}
		else if (whichApartment == 3)
		{
			Samount3++;
		}
		else {
			cout << "Error!. Wrong Choice, Please Start again" << endl;
			return false;
			break;
		}
	}

	for (int i = 0; i < Gamount1; i++) {
		Apparr[i] = new Garden();
		cout << "Enter data for garden #" << i + 1 << endl;
		Apparr[i]->setApp();
	}
	for (int i = 0; i < Pamount2; i++) {
		Apparr[i + Gamount1] = new Penthouse();
		cout << "Enter data for PentHouse #" << i + 1 - Gamount1 << endl;
		Apparr[i + Gamount1]->setApp();
	}
	for (int i = 0; i < Samount3; i++) {
		Apparr[i + Pamount2 + Gamount1] = new Standard_Appartment();
		cout << "Enter data for Standard #" << i + 1 - Pamount2 << endl;
		Apparr[i + Pamount2 + Gamount1]->setApp();
	}
	//cout << "check this" << endl;

	Building* building = new Building(building_Adress, buildlevels, Apparr);
	*ProjectArray[projindex] += building;
	cout << "building Added";
	Appartment** temp = new Appartment * [NumOfAppartment];
	for (int i = 0; i < NumOfAppartment; i++) {
		temp[i] = AppartemntArray[i];
	}
	delete[] AppartemntArray;
	AppartemntArray = new Appartment * [NumOfAppartment + AppAmount];
	for (int i = 0; i < NumOfAppartment; i++) {
		AppartemntArray[i] = temp[i];
	}
	for (int i = 0; i < AppAmount; i++) {
		AppartemntArray[i + NumOfAppartment - 1] = Apparr[i];
	}
	NumOfAppartment += AppAmount;
	return true;
}


bool HomeMarket::AddProject() {
	Project** tempArr = new Project * [++NumOfProject];
	for (int i = 0; i < NumOfProject - 1; i++)
		tempArr[i] = ProjectArray[i];

	tempArr[NumOfProject - 1] = new Project();
	tempArr[NumOfProject - 1]->setProject();

	delete[] ProjectArray;
	delete[] ProjectArray;
	ProjectArray = tempArr;
	return true;
}

Project** HomeMarket::getProjectArray()
{
	return ProjectArray;
}

void HomeMarket::Add_SalesMan()
{
	Person** tempArr = new Person * [++NumOfPerson];
	for (int i = 0; i < NumOfPerson - 1; i++)
		tempArr[i] = PersonArray[i];

	SalesMan* p = new SalesMan();
	p->setSeller();
	tempArr[NumOfPerson - 1] = p;

	delete[] PersonArray;
	PersonArray = tempArr;
}

void HomeMarket::Add_Customer() {

	Person** tempArr = new Person * [++NumOfPerson]; //new size +1
	for (int i = 0; i < NumOfPerson - 1; i++)
		tempArr[i] = PersonArray[i];

	Customer* c = new Customer(); //create new object from type customer 
	c->setCustomer(); //calling set customer function - put first last and budget of the customer
	for (int i = 0; i < NumOfProject; i++) //loop that checks if client name is in the system.
		if (!(PersonArray[i]->getfirstname().compare(c->getfirstname())) && (PersonArray[i]->getlastname().compare(c->getlastname()))) {
			cout << "There is a Person exsist alredy" << endl;
		}
	tempArr[NumOfPerson - 1] = c;
	delete[]PersonArray;
	PersonArray = tempArr;
}

void HomeMarket::Print_Apartment_by_Number() {
	int Appnum;
	string adressbuild;
	cout << "Please enter the Apartment number:" << endl;
	cin >> Appnum;
	cout << "Please enter the builsing's adress: " << endl;
	cin >> adressbuild;
	for (int i = 0; i < NumOfProject; i++) {
		for (int j = 0; j < ProjectArray[i]->getBuildsAmount(); j++) { //run over the builings amount 
			if (!(ProjectArray[i]->getbuildingArray()[j]->GetAdress().compare(adressbuild))) { //compare between the 2 adresses
				if (ProjectArray[i]->getbuildingArray()[j]->GetFloorAmount() >= Appnum) { //check the location of the appartment
					ProjectArray[i]->getbuildingArray()[j]->getApartment(Appnum)->print(); //sent the appartment to print
				}
			}
			else
				cout << "Error the building doesnt exsist " << endl;
		}
	}

}

void HomeMarket::Print_details_with_balcony() {
	int flag = 0;
	for (int i = 0; i < NumOfAppartment; i++) {
		Standard_Appartment* S = dynamic_cast<Standard_Appartment*>(AppartemntArray[i]);
		if (S) { //if it is an standard Appartment
			if (S->getbalconyamount() && S->getsoldornot()) {//2 balcony
				flag++;
				S->print();
			}

		}

	}
	if (flag == 0)
		cout << "There is no standart apartment with 2 balconies for sale" << endl;
}


void HomeMarket::Print_salesman_Salary() {
	string first;
	string last;
	int month;
	cout << "Please enter your first name" << endl;
	cin >> first;
	cout << "Please enter your last name" << endl;
	cin >> last;
	cout << "Please enter month" << endl;
	cin >> month;

	for (int i = 0; i < NumOfPerson; i++) {
		SalesMan* S = dynamic_cast<SalesMan*>(PersonArray[i]);
		if (S) {
			if (first == PersonArray[i]->getfirstname() && last == PersonArray[i]->getlastname()) {
				cout << "Sales man salary is:" << endl;
				cout << S->Calculate_Salary(month) << endl;
			}
		}
	}

}


void HomeMarket::Print_best_Apartments_details() {
	int CustomerID;
	cout << "Enter Customer ID :" << endl;
	cin >> CustomerID; //get the number of customers 
	bool flagCT = false;
	bool flagAp = false;
	for (int i = 0; i < this->NumOfPerson || flagCT == true; i++) { //run through persons 
		SalesMan* S = dynamic_cast<SalesMan*>(PersonArray[i]); //define pointer S from type Sales man 
		if (S) { //if we find an saller 
			for (int j = 0; j < S->getCTamount(); j++) {//go through customers array of the saller
				if (S->getCTArr()[j]->getCT_Id() == CustomerID) {
					flagCT = true; // find a Customer
					for (int k = 0; k < NumOfAppartment; k++) {
						if (!(AppartemntArray[k]->getsoldornot()) && (AppartemntArray[k]->Appartmment_Price() <= S->getCTArr()[j]->getBudget())) {
							flagAp = true;
							AppartemntArray[k]->print();
						}

					}
				}
			}
		}
	}
	if (flagAp == false)
		cout << "There is no appartment with this price" << endl;
	if (flagCT == false)
		cout << "The customer doesnt exsist" << endl;
}

void HomeMarket::Print_price_Penthouse() {
	string ProjectName;
	cout << "please enter project name ";
	cin >> ProjectName;
	bool flag = false;
	for (int i = 0; i < NumOfProject; i++) {
		if (ProjectArray[i]->getprojectName() == ProjectName) {
			flag = true;
			for (int j = 0; j < ProjectArray[i]->getBuildsAmount(); j++) {
				for (int k = 0; k < ProjectArray[i]->getbuildingArray()[j]->GetFloorAmount() * 2 - 2; k++) {
					Penthouse* P = dynamic_cast<Penthouse*>(ProjectArray[i]->getbuildingArray()[j]);
					if (P)  //t
						P->print();

				}
			}
		}
	}
	if (flag == false)
		cout << "There is no project found" << endl;
}

void HomeMarket::sale_Apartment() {
	string ProjectName;
	string AdressBuild;
	int numberofApp;
	int CustomerID;
	string firstname;
	string lastname;
	cout << "Enter project name: " << endl;
	cin >> ProjectName;
	cout << "The Adress building name: " << endl;
	cin >> AdressBuild;
	cout << "Enter the AppartmentID:" << endl;
	cin >> numberofApp;
	cout << "Enter the Customer ID:" << endl;
	cin >> CustomerID;
	cout << "Enter the First name  :" << endl;
	cin >> firstname;
	cout << "Enter the last name :" << endl;
	cin >> lastname;

	for (int i = 0; i < NumOfProject; i++) {
		if (ProjectArray[i]->getprojectName() == ProjectName) {


			for (int j = 0; j < ProjectArray[i]->getBuildsAmount(); j++) {
				Building** buildarr = ProjectArray[i]->getbuildingArray();
				if (buildarr[j]->GetAdress() == AdressBuild) {
					Building* building = buildarr[j];
					for (int k = 0; k < building->GetFloorAmount() * 2 - 2; k++) {
						Appartment* apartment = building->getApartment(k);
						if (apartment->getid() == numberofApp) {
							for (int Sindex = 0; Sindex < NumOfPerson; Sindex++) {
								SalesMan* seller = dynamic_cast<SalesMan*>(PersonArray[Sindex]);
								if (seller) {
									if (seller->getfirstname() == firstname && seller->getlastname() == lastname) {
										for (int Cindex = 0; Cindex < seller->getCTamount(); Cindex++) {
											Customer* customer = dynamic_cast<Customer*>(PersonArray[Cindex]);
											if (customer && CustomerID == customer->getCT_Id()) { //find a customer 
												if (customer->getBudget() >= apartment->Appartmment_Price())
													if (!(apartment->getsoldornot())) {
														Date* dat = new Date(rand()%30+1 , rand() % 12 + 1, rand() % 20 + 20000);
														customer->Buy(apartment, dat);

													}
											}
										}
									}
								}

							}

						}

					}

				}

			}
		}

	}
}


void HomeMarket::Print_lowest_Arnona() {
	Customer* lowest = nullptr;
	for (int i = 0; i < this->NumOfPerson; i++) {
		Customer* customer = dynamic_cast<Customer*>(this->PersonArray[i]);
		if (customer && customer->getNumOfApps() == 1) {
			if (customer->Calculate_Arnona() < lowest->Calculate_Arnona()) {
				lowest = customer;
			}
		}
	}
	if (lowest) {
		lowest->print();
	}
}
