#pragma once
#include "Appartment.h"
#include "Standard_Appartment.h"
#include <iostream>
#include<typeinfo>// RTTI
#include <string>
using namespace std;


class Garden: public Appartment
{
protected:
	int GardenArea;
	bool IsPool;

public:
	Garden();// def Ctor 
	Garden(int AppartmentID, int floor, int Area, bool IS_sale, int GardenArea, bool IsPool); //Manual Ctor
	Garden(const Garden& copy); //Copy ctor
	~Garden();//Dtor
	int Appartmment_Price();
	virtual void print();
	void setApp();
};

