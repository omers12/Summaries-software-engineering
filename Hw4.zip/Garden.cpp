#include "Garden.h"

Garden::Garden() : Appartment(), GardenArea(0), IsPool(false) {}

Garden::Garden(int AppartmentID, int floor, int Area, bool IS_sale, int GardenArea, bool IsPool):Appartment(AppartmentID, floor, IS_sale, GardenArea){
	this->GardenArea=GardenArea;
	this->IsPool = IsPool;
}


Garden::Garden(const Garden& copy) :Appartment(copy) {
	this->GardenArea = copy.GardenArea;
	this->IsPool = copy.IsPool;
}

Garden::~Garden() {}

int Garden::Appartmment_Price() {
	return 600000 + (this->GardenArea + this->Area) * 600 + this->IsPool * 100000;
}


void Garden::print() {
	cout << "---------------------------------------------------" << endl;
	cout << "Garden Apartment info: " << endl;
	Appartment::print();
	cout << "Garden Area: " << this->GardenArea << "\nPool: ";
	if (this->IsPool) {
		cout << "There is pool in Garden \n";
	}
	else {
		cout << "There is *NO* pool in Garden\n";
	}
	cout << "---------------------------------------------------" << endl;
}

void Garden::setApp()
{
	Appartment::setApp();
	cout << "Please enter 1 if the garden has pool and 0 otherwise:";
	cin >> IsPool;

	cout << "Please enter the area of the graden:";
	cin >> GardenArea;
}

