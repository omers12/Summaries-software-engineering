#pragma once
#include "Appartment.h"
class StandardAppartment: public Appartment
{
	int balkonyNumber;
	int* Size;
	StandardAppartment(int AppartmentID, int floor, int squre, bool IS_sale);


};

