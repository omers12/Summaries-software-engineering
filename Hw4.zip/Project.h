/*
Omer shay
322480807
*/
#pragma once
#include "Building.h"
#include <string.h>

class Project
{

protected:
	string ProjectName;
	int BuildingsAmount;
	Building** BuildingArray;

public:
	Project();
	
	Project(string ProjectName, int BuildingsAmount, Building** BuildingPtr);
	~Project();
	void print();
	Project& operator+=( Building* newBuilding); //+= operator to add the array new building 
	//void addBuilding(Building* BuildingPtr);
	int printNumBuilding(string Building_Adress); //
	string getprojectName();
	int getBuildsAmount();
	Building** getbuildingArray();
	void setProject();
	void setName(string name);
};



