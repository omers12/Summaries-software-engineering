/*
Omer shay
322480807
*/
#pragma once
#include "Person.h"
#include "Customer.h"
#include "Project.h"

class Project;
class Customer;
class SalesMan : public Person //a sales man is also a pesron 
{
protected:

	Project* project; //a pointer to project 
	int NumOfCustomers; //number of customers 
	Customer** CustomeArr; //dynamic array of pointers to customers 
public:

	SalesMan(const SalesMan& copy); //copy CTor
	SalesMan(string firstName,string lastName,Project* project,int NumOfCustomers, Customer** customArr); //Manual Ctor
	SalesMan(); //default Ctor
	~SalesMan(); //Dtor

	int Calculate_Salary(int month)const;
	virtual void print()const;
	int CountAppartments(int month);
	void AddCustom(Customer* customer);
	int getCTamount();
	Customer** getCTArr();
	Project* getproject();
	void setSeller();
};

