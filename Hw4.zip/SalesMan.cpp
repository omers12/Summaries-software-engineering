#pragma once
#include "SalesMan.h"


SalesMan::SalesMan():Person(), project(NULL), NumOfCustomers(0), CustomeArr(NULL){}


SalesMan::SalesMan(const SalesMan& copy):Person(copy){
	*this->project = *copy.project;
	this->NumOfCustomers = copy.NumOfCustomers;
	CustomeArr = new Customer*[NumOfCustomers];
	for (int i = 0; i < NumOfCustomers; i++) {
		this->CustomeArr[i] = copy.CustomeArr[i];
	}
	
}

SalesMan::SalesMan(string firstName, string lastName, Project* project, int NumOfCustomers, Customer** customArr):Person(firstName,lastName){
	this->project = project;
	this->NumOfCustomers = NumOfCustomers;
	CustomeArr = new Customer*[NumOfCustomers];
	for (int i = 0; i < NumOfCustomers; i++) {
		this->CustomeArr[i] = customArr[i];
	}
}



SalesMan::~SalesMan(){
	if (CustomeArr) {
		for (int i = 0; i < NumOfCustomers; i++) {
			delete[] CustomeArr[i];
		}
		delete[] CustomeArr;
		if(project)
		delete[] project;
	}
	
}





int SalesMan:: Calculate_Salary(int month)const { 
	int numStandard = 0, numPenthouse = 0, numGarden = 0, sum;
	for (int i = 0; i < NumOfCustomers; i++) //two loops, one that checks each client and one that checks each client apartments.
	{
		for (int j = 0; j < CustomeArr[i]->getNumOfApps(); j++)
		{
			Garden* pW = dynamic_cast<Garden*>(CustomeArr[i]->getApps()[j]); //casting each type of apartment with client apartments.
			if (pW) {
				if (CustomeArr[i]->getdate(j) == month) //check if client apartment been sold in the specific month given,.
				{
					numGarden++;

				}
			}
			Penthouse* pW1 = dynamic_cast<Penthouse*>(CustomeArr[i]->getApps()[j]);
			if (pW1) {
				if (CustomeArr[i]->getdate(j) == month)
				{
					numPenthouse++;

				}
			}
			Standard_Appartment* pW2 = dynamic_cast<Standard_Appartment*>(CustomeArr[i]->getApps()[j]);
			if (pW2) {
				if (CustomeArr[i]->getdate(j) == month)
				{
					numStandard++;

				}
			}
		}
	}
	sum = numStandard * 1000 + numPenthouse * 1500 + numGarden * 2000;
	return sum; //The salary of the salles man 
}


void SalesMan::print()const {
	cout << "****************** Sales Man ******************" << endl;
	Person::print(); //call to person virtual function to print the first and last name of Sales man \.
	cout << "Appartments: ";
	

	
	
	cout << "*******************************************" << endl;
}

int SalesMan::getCTamount()
{
	return this->NumOfCustomers;
}

Customer** SalesMan::getCTArr()
{
	return this->CustomeArr;
}

Project* SalesMan::getproject()
{
	return project;
}

void SalesMan::setSeller()
{
	Person::setPerson();
	project = new Project();
	string name;
	cout << "Please enter the sellers project's name:" << endl;
	cin >> name;
	project->setName(name);

	cout << "Please enter the amount of customers:" << endl;
	cin >> NumOfCustomers;
	
}
