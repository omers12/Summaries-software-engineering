#pragma once
#include "Penthouse.h"
#include <iostream>
using namespace std;

Penthouse::Penthouse(): Appartment(), Balcony_Pent_Size(0){}

Penthouse::Penthouse(int AppartmentID, int floor, int Area, bool IS_sale, int Balcony_Pent_Size):Appartment(AppartmentID, floor, IS_sale, Balcony_Pent_Size){
	this->Balcony_Pent_Size = Balcony_Pent_Size;
}

Penthouse::Penthouse(const Penthouse& copy) : Appartment(copy) {
	this->Balcony_Pent_Size = copy.Balcony_Pent_Size;
}

Penthouse::~Penthouse() {}



void Penthouse::print()
{
	Appartment::print();
	cout << "Balchoney Area: " << this->Balcony_Pent_Size << endl;
}

void Penthouse::setApp()
{
	Appartment::setApp();
	cout << "Please enter the size of the balcony:";
	cin >> Balcony_Pent_Size;
}

int Penthouse::Appartmment_Price()
{
	return  700000 + this->Area * 600 + this->Balcony_Pent_Size * 200;;
}
