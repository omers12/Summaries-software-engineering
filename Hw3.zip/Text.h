#pragma once
#include "Word.h"
class Text
{
private:
	Word** text; //dynamic array of pointers from type word - 
	int text_length;
	int HowManyWords(const char* sentence)const; //A method that counts the amount of words in the sentence.
	char createRandChar()const; //Create a random char variable.
	char createRandSize()const; //Create a random size of Text 
public:
	~Text();//defalut D'tor
	Text();//Default C'tor
	Text(const char* a); //manual C'tor/
	Text(const Text& copy);//manual Cpy C'tor/
	void initArray(int n); //A method for dynamic allocation of an array.
	void deleteArray(); //A method to delete an array
	int GetSize();
	void setTextLength(int n);
	Word& getText(int index);

//Operators
	Text& operator !();
	Text& operator &();
	Text& operator <<(int n);
	Text& operator >> (int n);
	Text& operator = (const Text& copy);
	Text& operator +=(int n);
	Text& operator -=(int n);
	Word& operator [](int index);
	friend ostream& operator << (ostream& output, const Text& object); //cout operator


};

