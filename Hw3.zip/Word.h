#pragma once
using namespace std;
#include <iostream>
#include <time.h >
#include <stdlib.h>
#include <math.h>
class Word
{
private:
	char* word;
	int word_length;
	int num_of_letters(const char* w)const;// a mathod that count the amount of letters in word 
	char createRandChar()const; // method that create a random char variable

	

public:
	Word(); //Default c'tor.
	Word(const char* w); //Manual c'tor.
	Word(const char* w, int n); //Manual c'tor.
	Word(const Word& copy); //Copy c'tor.
	~Word(); //D'tor.
	void initArray(int n); // init array and delete array
	void deleteArray(); //delete array 
	//Operators:
	
	Word& operator !();
	Word& operator &();
	Word& operator <<(int n);
	Word& operator >> (int n);
	Word& operator = (const Word& copy);
	Word& operator +=(int n);
	Word& operator -=(int n);
	char& operator [](int index);
	friend ostream& operator << (ostream& out, const Word&); //cout operator
	
};

