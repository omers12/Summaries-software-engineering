#pragma once 
#include "EncryptedText.h"

EncryptedText::EncryptedText() :textptr(NULL), key(NULL), status(0), key_size(0) { //Default c'tor.
	textptr = new Text("one two three four five");
}
EncryptedText::EncryptedText(const char* str, int status) : key(NULL), key_size(0) { //Manual c'tor.
	this->status = status;
	textptr = new Text(str);
}

EncryptedText::~EncryptedText() { //D'tor.
	delete textptr;
	delete[] key;
}

EncryptedText& EncryptedText::operator+=(int* user_key) {
	key_size = 0;
	while (user_key[key_size] != -2) { //Count the array size to the final condition, in this case -2.
		key_size++;
	}
	key = new int[key_size]; //Assigns dynamic memory of the array to the size above.
	for (int i = 0; i < key_size; i++)
		key[i] = user_key[i];
	return *this;
}

ostream& operator << (ostream& out, const EncryptedText& obj) {
	if (obj.status == 0 && obj.key == NULL) {
		cout << "The decrypted text: ";
		out << (*obj.textptr) << endl;
		cout << "The key: Empty" << endl;
	}
	if (obj.status == 0 && obj.key != NULL) {
		cout << "The encrypted text: ";
		out << (*obj.textptr) << endl;
		cout << "The key:" << endl;
		for (int i = 0; i < obj.key_size; i += 3)
		{
			cout << obj.key[i] << "  " << obj.key[i + 1] << "  " << obj.key[i + 2] << endl;
		}

	}
	if (obj.status == 1 && obj.key != NULL) {
		cout << "The encrypted text: ";
		out << (*obj.textptr) << endl;
		cout << "The key:" << endl;
		for (int i = 0; i < obj.key_size; i += 3)
		{
			cout << obj.key[i] << "  " << obj.key[i + 1] << "  " << obj.key[i + 2] << endl;
		}
	}
	if (obj.status == 2) {
		cout << "The decrypted text: ";
		out << (*obj.textptr) << endl;
	}

	cout << endl;
	return out;
}

EncryptedText& EncryptedText::operator!() {
	for (int i = 0; i < key_size; i += 3) {
		int code = key[i], text_or_word = key[i + 1], parameter = key[i + 2];
		if (text_or_word == -1) { //In case the user chooses to encrypt a statement.
			for (int j = 0; j < textptr->GetSize(); j++) {
				switch (code) {
				case 1: (*textptr) << parameter;
					break;
				case 2: (*textptr) >> parameter;
					break;
				case 3: (*textptr) += parameter;
					break;
				case 4: !(textptr->getText(j));
					continue;
				case 5: &(*textptr);
					break;
				}
				break;
			}
		}

		else { //In case the user chooses to encrypt a word.
			switch (code) {
			case 1: (textptr->getText(text_or_word)) << parameter;
				break;
			case 2: (textptr->getText(text_or_word)) << parameter;
				break;
			case 3: (*textptr) += parameter;
				break;
			case 4: !(textptr->getText(text_or_word));
				continue;
			case 5: &(textptr->getText(text_or_word));
				break;
			}
		}
	}
	return *this;
}

EncryptedText& EncryptedText::operator&() {
	for (int i = key_size - 1; i > 0; i -= 3) {
		int parameter = key[i], text_or_word = key[i - 1], code = key[i - 2];
		if (text_or_word == -1) { //In case the user chooses to encrypt a statement.
			for (int j = 0; j < textptr->GetSize(); j++) {
				switch (code) {
				case 1: (*textptr) >> parameter;
					break;
				case 2: (*textptr) << parameter;
					break;
				case 3: (*textptr) -= parameter;
					break;
				case 4: !(textptr->getText(j));
					continue;
				case 5: &(*textptr);
					break;
				}
				break;
			}
		}

		else { //In case the user chooses to encrypt a word.
			switch (code) {
			case 1: (textptr->getText(text_or_word)) >> parameter;
				continue;
			case 2: (textptr->getText(text_or_word)) << parameter;
				continue;
			case 3: (*textptr) -= parameter;
				continue;
			case 4: !(textptr->getText(text_or_word));
				continue;
			case 5: &(textptr->getText(text_or_word));
				continue;
			}
		}
	}
	return *this;
}