#pragma once
#include "Word.h"
#include "Text.h"
#include "EncryptedText.h"


int main() {
EncryptedText etext1("The London is capital of Great Britian.", 0);
int key1[] = { 3, -1, 4, 1, -1, 3, 1, 0, 4, 4, -1, 0, 5, -1, 0, -2 };
cout << etext1;
etext1 += key1;
cout << !etext1;
cout << "----------------------------------------------------------" << endl;
EncryptedText etext2("RH oLMWLM gSV yIRGRZM. tIVZG LU 3eCQ GZOXZKR", 1);
etext2 += key1;
cout << etext2;
&etext2;
cout << etext2;
}
	//	Word w("abcdef", 6);
	//	w[0] = 'x';
	//	w >> 2;
	//	cout << w << endl; // print : efxbcd
	//
	//	Text text1 = { "one", "two" };
	//	text1 >> 11;
	//	cout << text1;//print : five one two three four
	//	cout << text1[2] << endl;//print : two
	//	text1[2][3] = '9';
	//	cout << text1;//print : five one 9wo three four
	//	text1 += 2;
	//	cout << text1;//print : five one eSK1 9wo three four
	//}



