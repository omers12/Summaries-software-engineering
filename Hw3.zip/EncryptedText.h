#pragma once
#include "Text.h"

class EncryptedText
{
private:
	Text* textptr; // a pointer to text
	bool status;
	int* key;
	int key_size;


public:
	EncryptedText(); //Default C'tor.
	EncryptedText(const char* str, int status); //manual C'tor
	~EncryptedText(); //default D'tor
	EncryptedText& operator+=(int* user_key);
	EncryptedText& operator!();
	EncryptedText& operator&();
	friend ostream& operator <<(ostream&, const EncryptedText& obj); //send an object to print

};

